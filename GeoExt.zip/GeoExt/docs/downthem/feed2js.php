feed2js_ck = true;

document.write('<div class="rss-box">');
document.write('<ul class="rss-items">');
document.write('<li class="rss-item"><a class="rss-item" href="http://geoext.blogspot.com/2012/10/openlayers-3-invest-in-web-mapping.html" target="_self">OpenLayers 3: Invest in the web mapping future !</a><br />');
document.write('OpenLayers Community has initiated a call for funding in order to develop a...');
document.write('</li>');
document.write('<li class="rss-item"><a class="rss-item" href="http://geoext.blogspot.com/2012/05/geoext-2-more-technical-details.html" target="_self">GeoExt 2 - more technical details</a><br />');
document.write('This blog post provides more details on GeoExt 2 and Ext JS 4, focusing on ...');
document.write('</li>');
document.write('<li class="rss-item"><a class="rss-item" href="http://geoext.blogspot.com/2012/05/geoext2-sprint-results.html" target="_self">GeoExt2 Sprint Results</a><br />');
document.write('Today was the final day of the sprint, and we are proud to announce that Ge...');
document.write('</li>');
document.write('</ul></div>');
